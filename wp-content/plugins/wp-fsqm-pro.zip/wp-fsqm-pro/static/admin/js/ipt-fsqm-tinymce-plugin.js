(function() {
	tinymce.PluginManager.add( 'iptFSQMv3', function( editor, url ) {
		var menus = [], i, len, forms, themes;

		forms = iptFSQMTMMenu.forms;
		themes = iptFSQMTMMenu.themes;

		// Populate the menu
		// with built in objects
		menus = [
			// Insert System Shortcode
			{
				text: iptFSQMTML10n.l10n.ss.ss,
				icon: 'icon ipt-icomoon-cog',
				menu: [
					// User Portal
					{
						text: iptFSQMTML10n.l10n.ss.up,
						icon: 'icon ipt-icomoon-user',
						onclick: function() {
							var body = [], i, height = jQuery(window).height(), width = jQuery(window).width();
							var win = editor.windowManager.open({
								title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.ss.tb,
								height: ( height - 200 ),
								width: ( width < 900 ) ? ( width - 50 ) : 800,
								classes: 'ipt-fsqm-panel',
								autoScroll: true,
								body: [
									{
										type   : 'container',
										html   : '<h2 style="font-weight: bold;">' + iptFSQMTML10n.l10n.ss.uplabels.llogin_attr + '</h2>'
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPlogin',
										label  : iptFSQMTML10n.l10n.ss.uplabels.login_attr.login,
										value  : iptFSQMTML10n.l10n.ss.updefaults.login
									},
									{
										type   : 'checkbox',
										name   : 'fsqmUPshow_register',
										text   : iptFSQMTML10n.l10n.ss.uplabels.login_attr.show_register,
										checked : true
									},
									{
										type   : 'checkbox',
										name   : 'fsqmUPshow_forgot',
										text   : iptFSQMTML10n.l10n.ss.uplabels.login_attr.show_forgot,
										checked : true
									},
									{
										type   : 'container',
										html   : '<h2 style="font-weight: bold;">' + iptFSQMTML10n.l10n.ss.uplabels.lportal_attr + '</h2>'
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPtitle',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.title,
										value  : iptFSQMTML10n.l10n.ss.updefaults.title
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPcontent',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.content,
										value  : iptFSQMTML10n.l10n.ss.updefaults.content,
										tooltip: iptFSQMTML10n.l10n.ss.uplabels.portal_attr.contenttt,
										multiline: true,
										minHeight: 50
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPnosubmission',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.nosubmission,
										value  : iptFSQMTML10n.l10n.ss.updefaults.nosubmission
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPformlabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.formlabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.formlabel
									},
									{
										type   : 'checkbox',
										name   : 'fsqmUPfilters',
										text   : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.filters,
										checked: true,
										tooltip: iptFSQMTML10n.l10n.ss.uplabels.portal_attr.filterstt
									},
									{
										type   : 'checkbox',
										name   : 'fsqmUPshowcategory',
										text   : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.showcategory,
										checked : true
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPcategorylabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.categorylabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.categorylabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPdatelabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.datelabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.datelabel
									},
									{
										type   : 'checkbox',
										name   : 'fsqmUPshowscore',
										text   : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.showscore,
										checked : true,
										tooltip: iptFSQMTML10n.l10n.ss.uplabels.portal_attr.showscorett
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPscorelabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.scorelabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.scorelabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPmscorelabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.mscorelabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.mscorelabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPpscorelabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.pscorelabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.pscorelabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPactionlabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.actionlabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.actionlabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPlinklabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.linklabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.linklabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPeditlabel',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.editlabel,
										value  : iptFSQMTML10n.l10n.ss.updefaults.editlabel
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPavatar',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.avatar,
										value  : iptFSQMTML10n.l10n.ss.updefaults.avatar
									},
									{
									    type   : 'listbox',
									    name   : 'fsqmUPtheme',
									    label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.theme,
									    values : themes,
									    value  : 'designer-4'
									},
									{
										type   : 'textbox',
										name   : 'fsqmUPlogout_r',
										label  : iptFSQMTML10n.l10n.ss.uplabels.portal_attr.logout_r,
										value  : iptFSQMTML10n.l10n.ss.updefaults.logout_r,
										tooltip: iptFSQMTML10n.l10n.ss.uplabels.portal_attr.logout_r_tt
									}
								],
								onsubmit: function( e ) {
									var textboxAttrs = [ 'login', 'title', 'nosubmission', 'formlabel', 'categorylabel', 'datelabel', 'scorelabel', 'mscorelabel', 'pscorelabel', 'actionlabel', 'linklabel', 'editlabel', 'avatar', 'logout_r' ],
									checkboxAttrs = [ 'show_register', 'show_forgot', 'filters', 'showcategory', 'showscore' ],
									shortcode = '[ipt_fsqm_utrackback';
									console.log
									// Add the textbox attr
									for ( i in textboxAttrs ) {
										shortcode += ' ' + textboxAttrs[i] + '="' + e.data['fsqmUP'+textboxAttrs[i]] + '"';
									}
									// Add the checkboxAttrs
									for ( i in checkboxAttrs ) {
										shortcode += ' ' + checkboxAttrs[i] + '="' + ( e.data['fsqmUP'+checkboxAttrs[i]] == true ? '1' : '0' ) + '"';
									}
									// Add the theme and close shortcode tag
									shortcode += ' theme="' + e.data.fsqmUPtheme + '"]';

									// Add content and shortcode
									shortcode += e.data.fsqmUPcontent + '[/ipt_fsqm_utrackback]';

									editor.insertContent( '<br />' + shortcode + '<br />' );
								}
							});
						}
					},
					// Trackback
					{
						text: iptFSQMTML10n.l10n.ss.tb,
						icon: 'icon ipt-icomoon-retweet',
						onclick: function() {
							var win = editor.windowManager.open({
								title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.ss.tb,
								height: 100,
								width: 500,
								classes: 'ipt-fsqm-panel',
								body: [
									{
										type   : 'textbox',
										name   : 'fsqmTBFL',
										label  : iptFSQMTML10n.l10n.ss.tbfl,
										tooltip: iptFSQMTML10n.l10n.ss.tbfltt,
										value  : iptFSQMTML10n.l10n.ss.tbfll
									},
									{
										type   : 'textbox',
										name   : 'fsqmTBST',
										label  : iptFSQMTML10n.l10n.ss.tbsbtl,
										value  : iptFSQMTML10n.l10n.ss.tbsbt
									}
								],
								onsubmit: function( e ) {
									editor.insertContent( '<br />[ipt_fsqm_trackback label="' + e.data.fsqmTBFL + '" submit="' + e.data.fsqmTBST + '"]<br />' );
								}
							});
						}
					}
				]
			},
			// Insert Forms
			{
				text: iptFSQMTML10n.l10n.if,
				icon: 'icon ipt-icomoon-insert-template',
				onclick: function() {
					editor.windowManager.open( {
						title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.if,
						height: 100,
						width: 500,
						classes: 'ipt-fsqm-panel',
						body: [
							{
								type: 'listbox',
								name: 'fsqmFormID',
								label: iptFSQMTML10n.l10n.ifl,
								values: forms
							}
						],
						onsubmit: function( e ) {
							editor.insertContent( '<br />[ipt_fsqm_form id="' + e.data.fsqmFormID + '"]<br />' );
						}
					});
				}
			},
			// Insert Trends
			{
				text: iptFSQMTML10n.l10n.it,
				icon: 'icon ipt-icomoon-stats',
				onclick: function() {
					var activeFormID = null;
					editor.windowManager.open( {
						title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.it,
						height: 100,
						width: 500,
						classes: 'ipt-fsqm-panel',
						body: [
							{
								type: 'listbox',
								name: 'fsqmFormID',
								label: iptFSQMTML10n.l10n.ifl,
								values: forms
							}
						],
						onsubmit: function( e ) {
							// Get the form ID
							var formID = e.data.fsqmFormID;
							// Show another window to wait for ajax
							editor.windowManager.open({
								title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.it,
								height: 100,
								width: 500,
								body: [
									{
										type: 'container',
										html: iptFSQMTML10n.l10n.ajax
									}
								]
							});

							// Prep the ajax call
							jQuery.get( ajaxurl, {
								action: 'ipt_fsqm_shortcode_get_mcqs_for_mce',
								wpnonce: iptFSQMTML10n.nonce,
								form_id: formID
							}, function(data) {
								editor.windowManager.close();
								if ( data.html != undefined && data.mcqs == undefined ) {
									editor.windowManager.alert( 'Error! ' + data.html );
									return;
								}
								var body = [], win;
								// Visualization column text
								body[body.length] = {
									type: 'textbox',
									name: 'fsqmTVC',
									label: iptFSQMTML10n.l10n.itvc,
									value: iptFSQMTML10n.l10n.itvcv
								};
								// Server load
								body[body.length] = {
									type   : 'listbox',
									name   : 'fsqmTSL',
									label  : iptFSQMTML10n.l10n.itvsl,
									values : iptFSQMTML10n.l10n.itvsllb
								};
								var onGoingCheck = false;
								// Questions
								for ( i in data.mcqs ) {
									body[body.length] = {
										type   : 'checkbox',
										name   : 'fsqmMID' + data.mcqs[i].value,
										label  : data.mcqs[i].value == 'all' ? iptFSQMTML10n.l10n.salabel : '',
										text   : data.mcqs[i].text,
										checked : data.mcqs[i].value == 'all' ? true : false,
										onChange: function( e ) {
											if ( onGoingCheck ) {
												return;
											}
											onGoingCheck = true;
											var elm;
											// Change Show All
											if ( this._name != 'fsqmMIDall' ) {
												elm = win.find( '#fsqmMIDall' );
												elm.checked( false );
												elm.value( false );
											// Disable other checkboxes
											} else {
												for ( i in data.mcqs ) {
													if ( data.mcqs[i].value != 'all' ) {
														elm = win.find( '#fsqmMID' + data.mcqs[i].value );
														elm.checked( false );
														elm.value( false );
													}
												}
											}
											onGoingCheck = false;
										}
									};
								}
								var height = jQuery(window).height(), width = jQuery(window).width();
								win = editor.windowManager.open({
									title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.it,
									height: ( height - 200 ),
									width: ( width < 900 ) ? ( width - 50 ) : 800,
									autoScroll: true,
									classes: 'ipt-fsqm-panel',
									body: body,
									onsubmit: function( e ) {
										var shortcode = '[ipt_fsqm_trends form_id="' + formID + '"' + ' load="' + e.data.fsqmTSL + '" title="' + e.data.fsqmTVC + '" mcq_ids="';

										if ( e.data.fsqmMIDall == true ) {
											shortcode += 'all';
										} else {
											var mcq_ids = [];
											for ( i in data.mcqs ) {
												if ( e.data['fsqmMID' + data.mcqs[i].value ] == true ) {
													mcq_ids.push( data.mcqs[i].value );
												}
											}
											shortcode += mcq_ids.join( ',' );
										}

										shortcode += '"]';
										editor.insertContent( '<br />' + shortcode + '<br />' );
									}
								});
							}).fail(function() {
								editor.windowManager.close();
								editor.windowManager.alert('Error! Could not connect to server');
							});
						}
					});
				}
			},
			// Insert Popup Forms
			{
				text: iptFSQMTML10n.l10n.pf,
				icon: 'icon ipt-icomoon-newtab',
				onclick: function() {
					var win, height = jQuery(window).height(), width = jQuery(window).width();
					win = editor.windowManager.open({
						title: iptFSQMTML10n.l10n.slabel + iptFSQMTML10n.l10n.pf,
						height: ( height < 850 ) ? ( height - 100 ) : 750,
						width: ( width < 900 ) ? ( width - 50 ) : 800,
						autoScroll: true,
						classes: 'ipt-fsqm-panel',
						body: [
							{
								type: 'listbox',
								name: 'fsqmFormID',
								label: iptFSQMTML10n.l10n.ifl,
								values: forms
							},
							{
								type   : 'textbox',
								name   : 'fsqmPFBT',
								label  : iptFSQMTML10n.l10n.pfbt,
								value  : iptFSQMTML10n.l10n.pfbtl
							},
							{
								type   : 'colorpicker',
								name   : 'fsqmPFBC',
								label  : iptFSQMTML10n.l10n.pfbc,
								value  : '#ffffff',
								onChange: function(e) {
									jQuery('#ipt_fsqmPFPVDIV').css( 'color', this.value() );
								}
							},
							{
								type   : 'colorpicker',
								name   : 'fsqmPFBBC',
								label  : iptFSQMTML10n.l10n.pfbbc,
								value  : '#3C609E',
								onChange: function(e) {
									jQuery('#ipt_fsqmPFPVDIV').css( 'background-color', this.value() );
								}
							},
							{
								type   : 'listbox',
								name   : 'fsqmPFBP',
								label  : iptFSQMTML10n.l10n.pfbp,
								values : iptFSQMTML10n.l10n.pfbplb
							},
							{
								type   : 'container',
								name   : 'fsqmPFPV',
								label  : iptFSQMTML10n.l10n.pfpv,
								html   : '<div id="ipt_fsqmPFPVDIV" style="width: 200px;margin: 10px auto;background-color: #3C609E;color: #fff;height: 50px;border-radius: 5px 5px 0 0;text-align: center;line-height: 50px;">' + iptFSQMTML10n.l10n.pfbtl + '</div>'
							}
						],
						onsubmit: function( e ) {
							var shortcode = '[ipt_fsqm_popup form_id="' + e.data.fsqmFormID + '" pos="' + e.data.fsqmPFBP + '" color="' + e.data.fsqmPFBC + '" bgcolor="' + e.data.fsqmPFBBC + '"]' + e.data.fsqmPFBT + '[/ipt_fsqm_popup]';
							editor.insertContent( '<br />' + shortcode + '<br />' );
							// Show popup for hidden trigger
							if ( e.data.fsqmPFBP == 'h' ) {
								var btnHTML = '<a href="#ipt-fsqm-popup-form-' + e.data.fsqmFormID + '" data-remodal-target="ipt-fsqm-popup-form-' + e.data.fsqmFormID + '">' + e.data.fsqmPFBT + '</a>';
								editor.windowManager.confirm( iptFSQMTML10n.l10n.pfmt + '  -  ' + btnHTML, function( s ) {
									if ( s ) {
										editor.insertContent( '<br />' + btnHTML + '<br />' );
									}
								} );
							}
						}
					});
				}
			}
		];

		// Open up scope for third party integrations
		for ( i in iptFSQMTMMenu.addons ) {
			if ( typeof iptFSQMTMMenu.addons[i] == 'function' ) {
				menus[menus.length] = iptFSQMTMMenu.addons[i].apply( this, [ editor, url, forms, themes ] );
			}
		}

		// Add the editor button
		editor.addButton( 'ipt_fsqm_tmce_menubutton', {
			title: iptFSQMTML10n.l10n.label,
			type: 'menubutton',
			icon: 'ipt-fsqmic-small-logo',
			menu: menus
		} );

		// Peace
	} );
})();
