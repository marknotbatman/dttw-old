window.iptFSQMTMMenu = {
	forms: [],
	themes: [],
	addons: []
};

var i;
// Prepopulate the forms for easier entry
if ( typeof ( iptFSQMTML10n.forms ) == 'object' && iptFSQMTML10n.forms.length > 0 ) {
	for ( i in iptFSQMTML10n.forms ) {
		iptFSQMTMMenu.forms[iptFSQMTMMenu.forms.length] = {
			text: iptFSQMTML10n.forms[i].name,
			value: iptFSQMTML10n.forms[i].id
		};
	}
}

// Prepopulate the themes for easier entry
if ( typeof ( iptFSQMTML10n.themes ) == 'object' ) {
	for ( i in iptFSQMTML10n.themes ) {
		iptFSQMTMMenu.themes[iptFSQMTMMenu.themes.length] = {
			text: iptFSQMTML10n.themes[i],
			value: i
		};
	}
}
