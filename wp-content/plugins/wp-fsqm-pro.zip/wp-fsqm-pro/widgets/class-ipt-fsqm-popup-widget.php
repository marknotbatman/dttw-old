<?php
/**
 * WP Feedback, Survey & Quiz Manager Pro Forms Widget
 *
 * Adds a widget to display forms on sidebars
 *
 * @package WP Feedback, Surver & Quiz Manager - Pro
 * @subpackage Widgets
 * @author Swashata Ghosh <swashata@ipanelthemes.com>
 */

class IPT_FSQM_Popup_Widget extends WP_Widget {

	/*==========================================================================
	 * Static methods
	 *========================================================================*/
	public static $instantiated = false;
	public static function init() {
		if ( self::$instantiated === true ) {
			return;
		}
		self::$instantiated = true;
		add_action( 'widgets_init', function() {
			register_widget( 'IPT_FSQM_Popup_Widget' );
		} );
	}


	/*==========================================================================
	 * Widget methods
	 *========================================================================*/

	/**
	 * Constructor
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ipt_fsqm_popup_widget',
			'description' => __( 'Insert FSQM Pro managed popups to your theme.', 'ipt_fsqm' ),
		);
		parent::__construct( 'ipt_fsqm_popup_widget', __( 'FSQM Pro - Insert Popup', 'ipt_fsqm' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// Config the JS
		$config_json = new stdClass();
		$config_json->label = $instance['button_text'];
		$config_json->color = '#' . $instance['button_color'];
		$config_json->bgcolor = '#' . $instance['button_bg_color'];
		$config_json->position = $instance['button_pos'];
		$config_json->formID = $instance['form_id'];
		// Config the PHP
		global $ipt_fsqm_popup_forms;
		if ( ! is_array( $ipt_fsqm_popup_forms ) ) {
			$ipt_fsqm_popup_forms = array();
		}
		$ipt_fsqm_popup_forms[] = $instance['form_id'];
		// Get output
		?>
<script type="text/javascript">
	if ( window.iptFSQMModalPopupForms === undefined ) {
		window.iptFSQMModalPopupForms = [];
	}
	window.iptFSQMModalPopupForms[window.iptFSQMModalPopupForms.length] = <?php echo json_encode( $config_json ); ?>;
</script>
		<?php
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// Parse the default form settings
		$instance = wp_parse_args( (array) $instance, array(
			'form_id' => '0',
			'button_text' => __( 'Popup Form', 'ipt_fsqm' ),
			'button_color' => 'ffffff',
			'button_bg_color' => '3c609e',
			'button_pos' => 'br',
		) );
		$positions = array(
			'r' => __( 'Right', 'ipt_fsqm' ),
			'br' => __( 'Bottom Right', 'ipt_fsqm' ),
			'bc' => __( 'Bottom Center', 'ipt_fsqm' ),
			'bl' => __( 'Bottom Left', 'ipt_fsqm' ),
			'l' => __( 'Left', 'ipt_fsqm' ),
			'h' => __( 'Manual Trigger' ),
		);
		$forms = (array) IPT_FSQM_Form_Elements_Static::get_forms_for_select();
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'form_id' ); ?>"><?php _e ( 'Select Form', 'ipt_fsqm' ); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'form_id' ); ?>" id="<?php echo $this->get_field_id( 'form_id' ); ?>">
				<option value="0"<?php selected( $instance['form_id'], '0', true ); ?>><?php _e( '--please select a form--', 'ipt_fsqm' ); ?></option>
				<?php if ( ! empty( $forms ) ) : ?>
				<?php foreach ( $forms as $form ) : ?>
				<option value="<?php echo $form->id; ?>"<?php selected( $instance['form_id'], $form->id, true ) ?>><?php echo $form->name; ?></option>
				<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'button_text' ); ?>"><?php _e( 'Button Text', 'ipt_fsqm' ); ?></label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name( 'button_text' ); ?>" id="<?php echo $this->get_field_id( 'button_text' ); ?>" value="<?php echo esc_html( $instance['button_text'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'button_color' ); ?>"><?php _e( 'Button Text Color', 'ipt_fsqm' ); ?></label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name( 'button_color' ); ?>" id="<?php echo $this->get_field_id( 'button_color' ); ?>" value="<?php echo esc_html( $instance['button_color'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'button_bg_color' ); ?>"><?php _e( 'Button Background Color', 'ipt_fsqm' ); ?></label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name( 'button_bg_color' ); ?>" id="<?php echo $this->get_field_id( 'button_bg_color' ); ?>" value="<?php echo esc_html( $instance['button_bg_color'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'button_pos' ); ?>"><?php _e ( 'Select Form', 'ipt_fsqm' ); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'button_pos' ); ?>" id="<?php echo $this->get_field_id( 'button_pos' ); ?>">
				<?php foreach ( $positions as $p_key => $position ) : ?>
				<option value="<?php echo $p_key; ?>"<?php selected( $instance['button_pos'], $p_key, true ) ?>><?php echo $position; ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<?php _e( 'If you select Hidden / Manual Trigger, then make sure you have the following code available somewhere in the page:', 'ipt_fsqm' ); ?>
		</p>
		<p>
			<code class="ipt_fsqm_ppw_mt">
&lt;a href=&quot;#ipt-fsqm-popup-form-<?php echo $instance['form_id'] ?>&quot; data-remodal-target=&quot;ipt-fsqm-popup-form-<?php echo $instance['form_id'] ?>&quot;&gt;<?php echo $instance['button_text'] ?>&lt;/a&gt;
			</code>
		</p>
		<?php
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// Update the instance
		return $new_instance;
	}
}

IPT_FSQM_Popup_Widget::init();
