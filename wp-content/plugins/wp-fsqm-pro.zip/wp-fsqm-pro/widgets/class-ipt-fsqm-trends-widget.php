<?php
/**
 * WP Feedback, Survey & Quiz Manager Pro Forms Widget
 *
 * Adds a widget to display forms on sidebars
 *
 * @package WP Feedback, Surver & Quiz Manager - Pro
 * @subpackage Widgets
 * @author Swashata Ghosh <swashata@ipanelthemes.com>
 */

// TODO
// This will be implemented in v4.0
// When we will refurbish the reports section
// to include all kinds of question elements
class IPT_FSQM_Trends_Widget extends WP_Widget {

	/*==========================================================================
	 * Static methods
	 *========================================================================*/
	public static $instantiated = false;
	public static function init() {
		if ( self::$instantiated === true ) {
			return;
		}
		self::$instantiated = true;
		add_action( 'widgets_init', function() {
			register_widget( 'IPT_FSQM_Trends_Widget' );
		} );
	}


	/*==========================================================================
	 * Widget methods
	 *========================================================================*/

	/**
	 * Constructor
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ipt_fsqm_trends_widget',
			'description' => __( 'Insert FSQM Pro reports and analytics to your sidebars.', 'ipt_fsqm' ),
		);
		parent::__construct( 'ipt_fsqm_trends_widget', __( 'FSQM Pro - Insert Trends', 'ipt_fsqm' ), $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// Get widget arguments
		extract( $args, EXTR_SKIP );
		echo $before_widget;

		// Widget title
		$title = apply_filters( 'widget_title', $instance['title'] );

		if ( $title != '' ) {
			echo $before_title;
			echo $title;
			echo $after_title;
		}

		// Main Widget output
		// TODO

		echo $after_widget;
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// Parse the default form settings
		$instance = wp_parse_args( (array) $instance, array(
			'title' => '',
			'form_id' => '0',
			'mcqs' => 'all',
			'freetype' => 'all',
		) );
		$forms = (array) IPT_FSQM_Form_Elements_Static::get_forms_for_select();
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><strong><?php _e( 'Title', 'ipt_kb' ) ?></strong></label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name( 'title' ); ?>" id="<?php echo $this->get_field_id( 'title' ); ?>" value="<?php echo esc_html( $instance['title'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'form_id' ); ?>"><?php _e ( 'Select Form', 'ipt_fsqm' ); ?></label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'form_id' ); ?>" id="<?php echo $this->get_field_id( 'form_id' ); ?>">
				<option value="0"<?php selected( $instance['form_id'], '0', true ); ?>><?php _e( '--please select a form--', 'ipt_fsqm' ); ?></option>
				<?php if ( ! empty( $forms ) ) : ?>
				<?php foreach ( $forms as $form ) : ?>
				<option value="<?php echo $form->id; ?>"<?php selected( $instance['form_id'], $form->id, true ) ?>><?php echo $form->name; ?></option>
				<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</p>
		<?php
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// Update the form
		$updated_instance = $new_instance;
		$updated_instance['title'] = isset( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';
		return $updated_instance;
	}
}

IPT_FSQM_Trends_Widget::init();
