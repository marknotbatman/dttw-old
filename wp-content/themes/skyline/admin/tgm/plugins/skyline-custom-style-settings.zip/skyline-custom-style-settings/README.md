skyline-custom-styles=====================
A simple plugin which provides custom styles for the Skyline Theme.