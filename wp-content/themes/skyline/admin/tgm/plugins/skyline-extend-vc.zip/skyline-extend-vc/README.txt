skyline-extend-vc
=====================

This plugin adds exclusive Skyline elements for Visual Composer.