<div class="counter-item3" style="color: <?php echo esc_attr($counter3_text_color); ?>">
<div class="counter" data-end-count="<?php echo esc_attr($counter3_value); ?>" data-speed="2500" style="font-size: <?php echo esc_attr($counter3_font_size); ?>px; color: <?php echo esc_attr($counter3_text_color); ?> !important; line-height: 1">0</div>
</div>