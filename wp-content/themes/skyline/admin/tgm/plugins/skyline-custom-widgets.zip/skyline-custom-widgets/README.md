skyline-custom-widgets=====================
A simple plugin which provides custom widgets for the Skyline Theme.