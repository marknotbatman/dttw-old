skyline-custom-posts
=====================


A simple plugin which creates custom post types for the Skyline Theme.

Post Types: Portfolio and Team Members